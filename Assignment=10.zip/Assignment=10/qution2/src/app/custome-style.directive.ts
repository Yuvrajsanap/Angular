import { Directive, ElementRef } from '@angular/core';

@Directive({
  selector: '[appCustomeStyle]',
  standalone: true
})
export class CustomeStyleDirective {

  constructor(public obj : ElementRef) { 

    this.obj.nativeElement.style.background='yellow';
    this.obj.nativeElement.style.fontStyle='bold';
    
  }


}
