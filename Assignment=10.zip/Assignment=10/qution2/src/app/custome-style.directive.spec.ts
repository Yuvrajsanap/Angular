import { CustomeStyleDirective } from './custome-style.directive';

describe('CustomeStyleDirective', () => {
  it('should create an instance', () => {
    const directive = new CustomeStyleDirective();
    expect(directive).toBeTruthy();
  });
});
