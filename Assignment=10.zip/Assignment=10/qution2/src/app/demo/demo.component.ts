import { Component } from '@angular/core';
import { CustomeStyleDirective } from '../custome-style.directive';

@Component({
  selector: 'app-demo',
  standalone: true,
  imports: [CustomeStyleDirective],
  templateUrl: './demo.component.html',
  styleUrl: './demo.component.css'
})
export class DemoComponent {

}
