import { CompSuccesDirective } from './comp-succes.directive';

describe('CompSuccesDirective', () => {
  it('should create an instance', () => {
    const directive = new CompSuccesDirective();
    expect(directive).toBeTruthy();
  });
});
