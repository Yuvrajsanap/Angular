import { Component } from '@angular/core';
import { CompSuccesDirective } from '../comp-succes.directive';
import { CompFailureDirective } from '../comp-failure.directive';
@Component({
  selector: 'app-demo',
  standalone: true,
  imports: [CompSuccesDirective, CompFailureDirective],
  templateUrl: './demo.component.html',
  styleUrl: './demo.component.css'
})
export class DemoComponent {

}
