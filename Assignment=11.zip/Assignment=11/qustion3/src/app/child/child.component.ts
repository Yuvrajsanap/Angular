import { Component } from '@angular/core';
import { NumberService } from '../number.service';
import { StringService } from '../string.service';
@Component({
  selector: 'app-child',
  standalone: true,
  imports: [],
  templateUrl: './child.component.html',
  styleUrl: './child.component.css',
  providers:[NumberService,StringService]
})
export class ChildComponent {

  public value1:string="";
  public value2:number=0;

  constructor(private obj1:NumberService,private obj2:StringService)
  {
   this.value1=this.obj1.ChkPrime(115); 
   this.value2=this.obj2.CountCapital("Yuvraj Sanap");
  }
}
