import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class NumberService {

  constructor() { }

  ChkPrime(No:number)
  {
    let flag:Boolean=true;
    let i:number=0;

    for(i=2;i<=(No/2);i++)
    {
      if((No%i)==0)
      {
        flag=false;
      }
    }
    
    if(flag==true)
    {
      return "Number is prime";
    }
    else{
      return "Number is not prime";
    }
  }
}
