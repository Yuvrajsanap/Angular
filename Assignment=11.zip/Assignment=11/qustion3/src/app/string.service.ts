import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StringService {

  constructor() { }

  CountCapital(char:string)
  {
    let i:number=0;
    let count:number=0;

    for(i=0;i<=char.length;i++)
    {
      if(char[i]>='A'&& char[i]<='Z')
      {
        count++;
      }
    }
    return count;
  }
}
