import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class NumberService {

  constructor() { }

   ChkPrime(No:number)
  {
   let i:number=0;
   let flag:Boolean=true;
   for(i=2;i<=(No/2);i++)
   {
    if(No%i==0)
    {
      flag=false;
    }
   } 

   if(flag==true)
   {
    return "Number is prime";
   }
   else
   {
    return "Number is not prime";
   }
  }
  
}
