import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StringService {

  constructor() { }

  CountCapital(char:string):number
  {
    let Count:any=0;
    let i:number=0;
    for(i=0;i<=char.length;i++)
    {
      if(char[i]>='A' && char[i]<='Z')
      {
        Count++;
      }
    }
    return Count;


  }
}
