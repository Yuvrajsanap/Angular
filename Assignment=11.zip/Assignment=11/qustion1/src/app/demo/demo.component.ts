import { Component } from '@angular/core';
import { ArithmaticService } from '../arithmatic.service';
@Component({
  selector: 'app-demo',
  standalone: true,
  imports: [],
  templateUrl: './demo.component.html',
  styleUrl: './demo.component.css',
  providers:[ArithmaticService]
})
export class DemoComponent {
    public value1:number=0;
    public value2:number=0;

    constructor(private obj:ArithmaticService)
    {
      this.value1=this.obj.Add(10,20);
      this.value2=this.obj.Sub(65,10);
    }
}
