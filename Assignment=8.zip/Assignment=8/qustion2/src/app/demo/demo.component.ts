import { Component,EventEmitter, Input, Output} from '@angular/core';

@Component({
  selector: 'app-demo',
  standalone: true,
  imports: [],
  templateUrl: './demo.component.html',
  styleUrl: './demo.component.css'
})
export class DemoComponent {
  @Input() public Bowl:any;
  @Output() public LaserLigth = new EventEmitter();

  public SendMessage()
  {
    this.LaserLigth.emit("Hello word from chiled");
  }
}
